export function dataTable() {
    let dataTable = new simpleDatatables.DataTable("#table1");
}